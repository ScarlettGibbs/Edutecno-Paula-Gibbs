<template>
  <div class="about">
    <h1>Mi Pagina VueJS</h1>
    <p>Creada para probar Despliege con Parcel</p>
    <p>Atte.</p>
    <p>Scarlett Gibbs</p>
  </div>
</template>
<style scoped>
  h1{
    margin: 15px;
  }
  p{
    margin: 20px;
  }
</style>